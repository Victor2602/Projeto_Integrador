import { useState } from 'react';
import { LoginPage, mockUsers } from './components/LoginPage';
import { SignupPage, SignupData } from './components/SignupPage';
import { DiscenteDashboard } from './components/DiscenteDashboard';
import { DocenteDashboard } from './components/DocenteDashboard';
import { FuncionarioDashboard } from './components/FuncionarioDashboard';
import { AdministradorDashboard } from './components/AdministradorDashboard';
import { FornecedorDashboard } from './components/FornecedorDashboard';

export type UserRole = 'discente' | 'docente' | 'funcionario' | 'administrador' | 'fornecedor' | null;

export interface UserData {
  email: string;
  name: string;
  role: UserRole;
}

type AppView = 'login' | 'signup' | 'dashboard';

export default function App() {
  const [currentView, setCurrentView] = useState<AppView>('login');
  const [currentUser, setCurrentUser] = useState<UserData | null>(null);

  const handleLogin = (email: string, password: string) => {
    const user = mockUsers.find(u => u.email === email && u.password === password);

    if (user) {
      setCurrentUser({
        email: user.email,
        name: user.name,
        role: user.role
      });
      setCurrentView('dashboard');
    } else {
      alert('E-mail ou senha incorretos');
    }
  };

  const handleSignup = (data: SignupData) => {
    if (data.role === 'fornecedor') {
      alert('Cadastro de fornecedor enviado para análise! Aguarde a aprovação do administrador.');
    } else {
      alert('Cadastro realizado com sucesso! Faça login para continuar.');
    }
    setCurrentView('login');
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentView('login');
  };

  if (currentView === 'login') {
    return (
      <LoginPage
        onLogin={handleLogin}
        onGoToSignup={() => setCurrentView('signup')}
      />
    );
  }

  if (currentView === 'signup') {
    return (
      <SignupPage
        onSignup={handleSignup}
        onBackToLogin={() => setCurrentView('login')}
      />
    );
  }

  if (!currentUser) {
    return <LoginPage onLogin={handleLogin} onGoToSignup={() => setCurrentView('signup')} />;
  }

  return (
    <div className="size-full">
      {currentUser.role === 'discente' && <DiscenteDashboard onLogout={handleLogout} userData={currentUser} />}
      {currentUser.role === 'docente' && <DocenteDashboard onLogout={handleLogout} />}
      {currentUser.role === 'funcionario' && <FuncionarioDashboard onLogout={handleLogout} />}
      {currentUser.role === 'administrador' && <AdministradorDashboard onLogout={handleLogout} />}
      {currentUser.role === 'fornecedor' && <FornecedorDashboard onLogout={handleLogout} userData={currentUser} />}
    </div>
  );
}