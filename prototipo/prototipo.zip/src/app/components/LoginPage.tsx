import { useState } from 'react';
import { GraduationCap, BookOpen, FileText, Shield, Lock, Mail, Truck } from 'lucide-react';
import { UserRole } from '../App';

interface LoginPageProps {
  onLogin: (email: string, password: string) => void;
  onGoToSignup: () => void;
}

interface UserAccount {
  email: string;
  password: string;
  role: UserRole;
  name: string;
}

const mockUsers: UserAccount[] = [
  { email: 'discente@edu.br', password: '123456', role: 'discente', name: 'João Pedro Silva' },
  { email: 'docente@edu.br', password: '123456', role: 'docente', name: 'Prof. João Silva' },
  { email: 'funcionario@edu.br', password: '123456', role: 'funcionario', name: 'Maria Santos' },
  { email: 'admin@edu.br', password: '123456', role: 'administrador', name: 'Carlos Admin' },
  { email: 'fornecedor@edu.br', password: '123456', role: 'fornecedor', name: 'Fornecedor Demo' },
];

export function LoginPage({ onLogin, onGoToSignup }: LoginPageProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!email || !password) {
      setError('Por favor, preencha todos os campos');
      return;
    }

    onLogin(email, password);
  };

  const roleInfo = [
    { role: 'discente', icon: GraduationCap, label: 'Discente', email: 'discente@edu.br', color: 'text-blue-500' },
    { role: 'docente', icon: BookOpen, label: 'Docente', email: 'docente@edu.br', color: 'text-green-500' },
    { role: 'funcionario', icon: FileText, label: 'Funcionário', email: 'funcionario@edu.br', color: 'text-orange-500' },
    { role: 'administrador', icon: Shield, label: 'Administrador', email: 'admin@edu.br', color: 'text-red-500' },
    { role: 'fornecedor', icon: Truck, label: 'Fornecedor', email: 'fornecedor@edu.br', color: 'text-purple-500' },
  ];

  return (
    <div className="min-h-screen flex bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <GraduationCap className="w-8 h-8 text-white" />
            </div>
            <h1 className="mb-2">Sistema Acadêmico</h1>
            <p className="text-slate-600">Faça login para acessar sua área</p>
          </div>

          <div className="bg-white rounded-2xl shadow-xl p-8 border border-slate-200">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-slate-700 mb-2">E-mail</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="seu.email@edu.br"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 mb-2">Senha</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="••••••"
                  />
                </div>
              </div>

              {error && (
                <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
                  {error}
                </div>
              )}

              <button
                type="submit"
                className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white py-3 rounded-lg hover:from-blue-600 hover:to-purple-700 transition-all duration-300 shadow-lg hover:shadow-xl"
              >
                Entrar
              </button>
            </form>

            <div className="mt-6 text-center space-y-3">
              <a href="#" className="block text-blue-500 hover:text-blue-700">
                Esqueceu sua senha?
              </a>
              <div className="border-t border-slate-200 pt-4">
                <p className="text-slate-600 mb-2">Não tem uma conta?</p>
                <button
                  onClick={onGoToSignup}
                  type="button"
                  className="text-blue-500 hover:text-blue-700 font-semibold"
                >
                  Criar nova conta
                </button>
              </div>
            </div>
          </div>

          <div className="mt-8 bg-white rounded-xl p-6 border border-slate-200">
            <p className="text-slate-600 mb-4">Contas de demonstração:</p>
            <div className="space-y-2">
              {roleInfo.map((info) => {
                const Icon = info.icon;
                return (
                  <button
                    key={info.role}
                    onClick={() => {
                      setEmail(info.email);
                      setPassword('123456');
                    }}
                    className="w-full flex items-center gap-3 p-3 hover:bg-slate-50 rounded-lg transition-colors text-left"
                  >
                    <Icon className={`w-5 h-5 ${info.color}`} />
                    <div className="flex-1">
                      <p className="text-slate-700">{info.label}</p>
                      <p className="text-slate-500">{info.email}</p>
                    </div>
                  </button>
                );
              })}
            </div>
            <p className="text-slate-500 mt-4">Senha para todos: 123456</p>
          </div>
        </div>
      </div>

      <div className="hidden lg:flex flex-1 bg-gradient-to-br from-blue-500 to-purple-600 items-center justify-center p-8">
        <div className="text-white text-center max-w-md">
          <h2 className="mb-6">Gestão Acadêmica Completa</h2>
          <p className="text-blue-100 mb-8">
            Sistema integrado para estudantes, professores, funcionários e administradores.
            Gerencie matrículas, notas, frequências e muito mais em um único lugar.
          </p>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
              <p className="mb-1">2,847</p>
              <p className="text-blue-100">Estudantes</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
              <p className="mb-1">156</p>
              <p className="text-blue-100">Professores</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
              <p className="mb-1">24</p>
              <p className="text-blue-100">Cursos</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
              <p className="mb-1">87%</p>
              <p className="text-blue-100">Aprovação</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export { mockUsers };
