import { useState } from 'react';
import { BookOpen, Users, Calendar, FileCheck, LogOut, User, ClipboardList, TrendingUp, Settings, Phone, Mail, MapPin, X } from 'lucide-react';

interface DocenteDashboardProps {
  onLogout: () => void;
}

interface DocenteProfile {
  nome: string;
  email: string;
  emailPessoal: string;
  telefone: string;
  endereco: string;
  departamento: string;
}

export function DocenteDashboard({ onLogout }: DocenteDashboardProps) {
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [profile, setProfile] = useState<DocenteProfile>({
    nome: 'Prof. João Silva',
    email: 'docente@edu.br',
    emailPessoal: 'joao.silva@gmail.com',
    telefone: '(11) 98765-1234',
    endereco: 'Rua dos Professores, 456 - São Paulo, SP',
    departamento: 'Matemática'
  });

  const handleUpdateProfile = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Perfil atualizado com sucesso!');
    setShowProfileModal(false);
  };
  const turmas = [
    { codigo: 'MAT101', nome: 'Cálculo I', alunos: 45, periodo: '2026.1', horario: 'Seg/Qua 08:00-10:00' },
    { codigo: 'MAT201', nome: 'Cálculo II', alunos: 38, periodo: '2026.1', horario: 'Ter/Qui 14:00-16:00' },
    { codigo: 'MAT301', nome: 'Cálculo III', alunos: 32, periodo: '2026.1', horario: 'Sex 08:00-12:00' },
  ];

  const tarefasCorrigir = [
    { turma: 'Cálculo I', atividade: 'Prova P1', pendentes: 12, total: 45 },
    { turma: 'Cálculo II', atividade: 'Lista 3', pendentes: 8, total: 38 },
    { turma: 'Cálculo III', atividade: 'Trabalho Final', pendentes: 5, total: 32 },
  ];

  const proximasAulas = [
    { turma: 'Cálculo I', horario: '08:00 - 10:00', sala: 'Sala 301', data: 'Segunda-feira' },
    { turma: 'Cálculo II', horario: '14:00 - 16:00', sala: 'Sala 205', data: 'Terça-feira' },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b border-slate-200 px-6 py-4">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-green-500 flex items-center justify-center">
              <User className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="text-slate-500">Docente</p>
              <p className="text-slate-900">{profile.nome}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowProfileModal(true)}
              className="flex items-center gap-2 px-4 py-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <Settings className="w-4 h-4" />
              Perfil
            </button>
            <button
              onClick={onLogout}
              className="flex items-center gap-2 px-4 py-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <LogOut className="w-4 h-4" />
              Sair
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto p-6">
        <div className="mb-8">
          <h1 className="mb-2">Portal do Professor</h1>
          <p className="text-slate-600">Bem-vindo, {profile.nome}!</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
            <div className="flex items-center justify-between mb-2">
              <BookOpen className="w-8 h-8 text-green-500" />
            </div>
            <p className="text-slate-500 mb-1">Turmas Ativas</p>
            <p className="text-green-500">{turmas.length}</p>
          </div>
          <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
            <div className="flex items-center justify-between mb-2">
              <Users className="w-8 h-8 text-blue-500" />
            </div>
            <p className="text-slate-500 mb-1">Total de Alunos</p>
            <p className="text-blue-500">115</p>
          </div>
          <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
            <div className="flex items-center justify-between mb-2">
              <FileCheck className="w-8 h-8 text-orange-500" />
            </div>
            <p className="text-slate-500 mb-1">Correções Pendentes</p>
            <p className="text-orange-500">25</p>
          </div>
          <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
            <div className="flex items-center justify-between mb-2">
              <TrendingUp className="w-8 h-8 text-purple-500" />
            </div>
            <p className="text-slate-500 mb-1">Média das Turmas</p>
            <p className="text-purple-500">7.8</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 mb-6">
              <h3 className="mb-6 flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-green-500" />
                Minhas Turmas
              </h3>
              <div className="space-y-4">
                {turmas.map((turma, index) => (
                  <div key={index} className="border border-slate-200 rounded-lg p-4 hover:border-green-300 transition-colors">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h4 className="mb-1">{turma.codigo} - {turma.nome}</h4>
                        <p className="text-slate-500">{turma.horario}</p>
                      </div>
                      <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full">
                        {turma.alunos} alunos
                      </span>
                    </div>
                    <div className="flex items-center gap-4 text-slate-500 mt-3">
                      <span>Período: {turma.periodo}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
              <h3 className="mb-6 flex items-center gap-2">
                <FileCheck className="w-5 h-5 text-orange-500" />
                Atividades para Corrigir
              </h3>
              <div className="space-y-4">
                {tarefasCorrigir.map((tarefa, index) => (
                  <div key={index} className="border border-slate-200 rounded-lg p-4 hover:border-orange-300 transition-colors">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h4 className="mb-1">{tarefa.atividade}</h4>
                        <p className="text-slate-500">{tarefa.turma}</p>
                      </div>
                      <span className="px-3 py-1 bg-orange-100 text-orange-700 rounded-full">
                        {tarefa.pendentes} pendentes
                      </span>
                    </div>
                    <div className="w-full bg-slate-200 rounded-full h-2">
                      <div
                        className="bg-orange-500 h-2 rounded-full transition-all"
                        style={{ width: `${((tarefa.total - tarefa.pendentes) / tarefa.total) * 100}%` }}
                      />
                    </div>
                    <p className="text-slate-500 mt-2">
                      {tarefa.total - tarefa.pendentes} de {tarefa.total} corrigidas
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
              <h3 className="mb-6 flex items-center gap-2">
                <Calendar className="w-5 h-5 text-purple-500" />
                Próximas Aulas
              </h3>
              <div className="space-y-3">
                {proximasAulas.map((aula, index) => (
                  <div key={index} className="border-l-4 border-purple-500 pl-4 py-2">
                    <p className="mb-1">{aula.turma}</p>
                    <p className="text-slate-500">{aula.horario}</p>
                    <p className="text-slate-500">{aula.sala}</p>
                    <span className="text-purple-600">{aula.data}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
              <h3 className="mb-6 flex items-center gap-2">
                <ClipboardList className="w-5 h-5 text-blue-500" />
                Ações Rápidas
              </h3>
              <div className="space-y-2">
                <button className="w-full text-left px-4 py-3 bg-slate-50 hover:bg-slate-100 rounded-lg transition-colors">
                  Lançar Notas
                </button>
                <button className="w-full text-left px-4 py-3 bg-slate-50 hover:bg-slate-100 rounded-lg transition-colors">
                  Registrar Frequência
                </button>
                <button className="w-full text-left px-4 py-3 bg-slate-50 hover:bg-slate-100 rounded-lg transition-colors">
                  Criar Atividade
                </button>
                <button className="w-full text-left px-4 py-3 bg-slate-50 hover:bg-slate-100 rounded-lg transition-colors">
                  Enviar Material
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>

      {showProfileModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden flex flex-col">
            <div className="p-6 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h2 className="mb-1">Meu Perfil</h2>
                <p className="text-slate-600">Gerencie suas informações pessoais</p>
              </div>
              <button
                onClick={() => setShowProfileModal(false)}
                className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <form onSubmit={handleUpdateProfile} className="flex-1 overflow-y-auto p-6 space-y-6">
              <div>
                <label className="block text-slate-700 mb-2">Nome Completo</label>
                <input
                  type="text"
                  value={profile.nome}
                  onChange={(e) => setProfile({ ...profile, nome: e.target.value })}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>

              <div>
                <label className="block text-slate-700 mb-2">E-mail Institucional</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <input
                    type="email"
                    value={profile.email}
                    className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg bg-slate-50"
                    disabled
                  />
                </div>
                <p className="text-slate-500 mt-1">Este campo não pode ser alterado</p>
              </div>

              <div>
                <label className="block text-slate-700 mb-2">E-mail Pessoal</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <input
                    type="email"
                    value={profile.emailPessoal}
                    onChange={(e) => setProfile({ ...profile, emailPessoal: e.target.value })}
                    className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 mb-2">Telefone</label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <input
                    type="tel"
                    value={profile.telefone}
                    onChange={(e) => setProfile({ ...profile, telefone: e.target.value })}
                    className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 mb-2">Endereço</label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                  <textarea
                    value={profile.endereco}
                    onChange={(e) => setProfile({ ...profile, endereco: e.target.value })}
                    rows={3}
                    className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 mb-2">Departamento</label>
                <input
                  type="text"
                  value={profile.departamento}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg bg-slate-50"
                  disabled
                />
              </div>
            </form>

            <div className="p-6 border-t border-slate-200 flex gap-3">
              <button
                type="button"
                onClick={() => setShowProfileModal(false)}
                className="flex-1 px-6 py-3 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={handleUpdateProfile}
                className="flex-1 px-6 py-3 bg-gradient-to-r from-green-500 to-green-600 text-white rounded-lg hover:from-green-600 hover:to-green-700 transition-colors"
              >
                Salvar Alterações
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
