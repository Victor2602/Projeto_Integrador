import { useState } from 'react';
import { FileText, Users, Calendar, CheckCircle2, LogOut, User, Clock, AlertCircle, Settings, Phone, Mail, MapPin, X } from 'lucide-react';

interface FuncionarioDashboardProps {
  onLogout: () => void;
}

interface FuncionarioProfile {
  nome: string;
  email: string;
  emailPessoal: string;
  telefone: string;
  endereco: string;
  setor: string;
}

export function FuncionarioDashboard({ onLogout }: FuncionarioDashboardProps) {
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [profile, setProfile] = useState<FuncionarioProfile>({
    nome: 'Maria Santos',
    email: 'funcionario@edu.br',
    emailPessoal: 'maria.santos@gmail.com',
    telefone: '(11) 98765-5678',
    endereco: 'Rua dos Funcionários, 789 - São Paulo, SP',
    setor: 'Secretaria Acadêmica'
  });

  const handleUpdateProfile = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Perfil atualizado com sucesso!');
    setShowProfileModal(false);
  };
  const solicitacoesPendentes = [
    { id: '2026-001', tipo: 'Matrícula', aluno: 'Ana Paula Silva', data: '13/05/2026', status: 'pendente' },
    { id: '2026-002', tipo: 'Histórico Escolar', aluno: 'Carlos Eduardo Santos', data: '12/05/2026', status: 'pendente' },
    { id: '2026-003', tipo: 'Declaração', aluno: 'Mariana Costa', data: '13/05/2026', status: 'pendente' },
    { id: '2026-004', tipo: 'Trancamento', aluno: 'Pedro Henrique Oliveira', data: '11/05/2026', status: 'em-analise' },
  ];

  const atendimentosHoje = [
    { horario: '09:00', tipo: 'Matrícula', aluno: 'João Pedro Silva' },
    { horario: '10:30', tipo: 'Documentação', aluno: 'Maria Fernanda Costa' },
    { horario: '14:00', tipo: 'Consulta', aluno: 'Lucas Martins' },
  ];

  const estatisticas = [
    { label: 'Solicitações Hoje', valor: '12', cor: 'text-blue-500' },
    { label: 'Atendimentos Realizados', valor: '8', cor: 'text-green-500' },
    { label: 'Pendentes', valor: '4', cor: 'text-orange-500' },
    { label: 'Tempo Médio', valor: '15min', cor: 'text-purple-500' },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b border-slate-200 px-6 py-4">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-orange-500 flex items-center justify-center">
              <User className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="text-slate-500">Funcionário Acadêmico</p>
              <p className="text-slate-900">{profile.nome}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowProfileModal(true)}
              className="flex items-center gap-2 px-4 py-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <Settings className="w-4 h-4" />
              Perfil
            </button>
            <button
              onClick={onLogout}
              className="flex items-center gap-2 px-4 py-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <LogOut className="w-4 h-4" />
              Sair
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto p-6">
        <div className="mb-8">
          <h1 className="mb-2">Portal Administrativo</h1>
          <p className="text-slate-600">Bem-vindo, {profile.nome}!</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {estatisticas.map((stat, index) => (
            <div key={index} className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
              <p className="text-slate-500 mb-1">{stat.label}</p>
              <p className={stat.cor}>{stat.valor}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="flex items-center gap-2">
                  <FileText className="w-5 h-5 text-orange-500" />
                  Solicitações Pendentes
                </h3>
                <span className="px-3 py-1 bg-orange-100 text-orange-700 rounded-full">
                  {solicitacoesPendentes.length} novas
                </span>
              </div>
              <div className="space-y-3">
                {solicitacoesPendentes.map((solicitacao) => (
                  <div key={solicitacao.id} className="border border-slate-200 rounded-lg p-4 hover:border-orange-300 transition-colors">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="text-slate-600">#{solicitacao.id}</span>
                          {solicitacao.status === 'pendente' ? (
                            <span className="px-2 py-1 bg-orange-100 text-orange-700 rounded-full flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              Pendente
                            </span>
                          ) : (
                            <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded-full flex items-center gap-1">
                              <AlertCircle className="w-3 h-3" />
                              Em Análise
                            </span>
                          )}
                        </div>
                        <h4 className="mb-1">{solicitacao.tipo}</h4>
                        <p className="text-slate-500">{solicitacao.aluno}</p>
                        <p className="text-slate-400 mt-2">Solicitado em: {solicitacao.data}</p>
                      </div>
                      <button className="px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors">
                        Processar
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
              <h3 className="mb-6 flex items-center gap-2">
                <Calendar className="w-5 h-5 text-purple-500" />
                Atendimentos Hoje
              </h3>
              <div className="space-y-3">
                {atendimentosHoje.map((atendimento, index) => (
                  <div key={index} className="border-l-4 border-purple-500 pl-4 py-2">
                    <p className="text-purple-600 mb-1">{atendimento.horario}</p>
                    <p className="mb-1">{atendimento.tipo}</p>
                    <p className="text-slate-500">{atendimento.aluno}</p>
                  </div>
                ))}
              </div>
              <button className="w-full mt-4 px-4 py-2 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors">
                Ver Agenda Completa
              </button>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
              <h3 className="mb-6 flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-green-500" />
                Ações Rápidas
              </h3>
              <div className="space-y-2">
                <button className="w-full text-left px-4 py-3 bg-slate-50 hover:bg-slate-100 rounded-lg transition-colors flex items-center gap-2">
                  <Users className="w-4 h-4 text-slate-500" />
                  Nova Matrícula
                </button>
                <button className="w-full text-left px-4 py-3 bg-slate-50 hover:bg-slate-100 rounded-lg transition-colors flex items-center gap-2">
                  <FileText className="w-4 h-4 text-slate-500" />
                  Emitir Documento
                </button>
                <button className="w-full text-left px-4 py-3 bg-slate-50 hover:bg-slate-100 rounded-lg transition-colors flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-slate-500" />
                  Agendar Atendimento
                </button>
                <button className="w-full text-left px-4 py-3 bg-slate-50 hover:bg-slate-100 rounded-lg transition-colors flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-slate-500" />
                  Consultar Histórico
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>

      {showProfileModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden flex flex-col">
            <div className="p-6 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h2 className="mb-1">Meu Perfil</h2>
                <p className="text-slate-600">Gerencie suas informações pessoais</p>
              </div>
              <button
                onClick={() => setShowProfileModal(false)}
                className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <form onSubmit={handleUpdateProfile} className="flex-1 overflow-y-auto p-6 space-y-6">
              <div>
                <label className="block text-slate-700 mb-2">Nome Completo</label>
                <input
                  type="text"
                  value={profile.nome}
                  onChange={(e) => setProfile({ ...profile, nome: e.target.value })}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
              </div>

              <div>
                <label className="block text-slate-700 mb-2">E-mail Institucional</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <input
                    type="email"
                    value={profile.email}
                    className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg bg-slate-50"
                    disabled
                  />
                </div>
                <p className="text-slate-500 mt-1">Este campo não pode ser alterado</p>
              </div>

              <div>
                <label className="block text-slate-700 mb-2">E-mail Pessoal</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <input
                    type="email"
                    value={profile.emailPessoal}
                    onChange={(e) => setProfile({ ...profile, emailPessoal: e.target.value })}
                    className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 mb-2">Telefone</label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <input
                    type="tel"
                    value={profile.telefone}
                    onChange={(e) => setProfile({ ...profile, telefone: e.target.value })}
                    className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 mb-2">Endereço</label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                  <textarea
                    value={profile.endereco}
                    onChange={(e) => setProfile({ ...profile, endereco: e.target.value })}
                    rows={3}
                    className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 mb-2">Setor</label>
                <input
                  type="text"
                  value={profile.setor}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg bg-slate-50"
                  disabled
                />
              </div>
            </form>

            <div className="p-6 border-t border-slate-200 flex gap-3">
              <button
                type="button"
                onClick={() => setShowProfileModal(false)}
                className="flex-1 px-6 py-3 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={handleUpdateProfile}
                className="flex-1 px-6 py-3 bg-gradient-to-r from-orange-500 to-orange-600 text-white rounded-lg hover:from-orange-600 hover:to-orange-700 transition-colors"
              >
                Salvar Alterações
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
