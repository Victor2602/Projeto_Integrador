import { useState } from 'react';
import { BookOpen, Calendar, FileText, Award, LogOut, User, Clock, CheckCircle2, Settings, Trash2, Phone, Mail, MapPin, X } from 'lucide-react';
import { UserData } from '../App';

interface DiscenteDashboardProps {
  onLogout: () => void;
  userData: UserData;
}

interface Subject {
  id: string;
  codigo: string;
  nome: string;
  professor: string;
  horario: string;
  vagas: number;
  vagasDisponiveis: number;
}

interface StudentProfile {
  nome: string;
  email: string;
  emailPessoal: string;
  telefone: string;
  endereco: string;
  curso: string;
  semestresInativos: number;
}

export function DiscenteDashboard({ onLogout, userData }: DiscenteDashboardProps) {
  const [showEnrollmentModal, setShowEnrollmentModal] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [selectedSubjects, setSelectedSubjects] = useState<string[]>([]);
  const [isEnrolledInSemester, setIsEnrolledInSemester] = useState(false);

  const [profile, setProfile] = useState<StudentProfile>({
    nome: userData.name,
    email: userData.email,
    emailPessoal: 'joao.pedro@gmail.com',
    telefone: '(11) 98765-4321',
    endereco: 'Rua das Flores, 123 - São Paulo, SP',
    curso: 'Engenharia de Computação',
    semestresInativos: 0
  });

  const availableSubjects: Subject[] = [
    { id: '1', codigo: 'MAT101', nome: 'Cálculo I', professor: 'Prof. João Silva', horario: 'Seg/Qua 08:00-10:00', vagas: 50, vagasDisponiveis: 12 },
    { id: '2', codigo: 'PRG101', nome: 'Programação I', professor: 'Profa. Maria Santos', horario: 'Ter/Qui 14:00-16:00', vagas: 45, vagasDisponiveis: 8 },
    { id: '3', codigo: 'FIS101', nome: 'Física I', professor: 'Prof. Carlos Oliveira', horario: 'Qua/Sex 10:00-12:00', vagas: 40, vagasDisponiveis: 15 },
    { id: '4', codigo: 'ING101', nome: 'Inglês Técnico', professor: 'Profa. Ana Costa', horario: 'Seg/Qua 14:00-16:00', vagas: 35, vagasDisponiveis: 5 },
    { id: '5', codigo: 'QUI101', nome: 'Química Geral', professor: 'Prof. Roberto Lima', horario: 'Ter/Qui 08:00-10:00', vagas: 40, vagasDisponiveis: 20 },
    { id: '6', codigo: 'ALG101', nome: 'Álgebra Linear', professor: 'Profa. Fernanda Rocha', horario: 'Sex 08:00-12:00', vagas: 30, vagasDisponiveis: 10 },
    { id: '7', codigo: 'HUM101', nome: 'Introdução às Humanidades', professor: 'Prof. Paulo Mendes', horario: 'Seg 14:00-18:00', vagas: 50, vagasDisponiveis: 25 },
    { id: '8', codigo: 'EST101', nome: 'Estatística I', professor: 'Profa. Juliana Barros', horario: 'Qua 14:00-18:00', vagas: 35, vagasDisponiveis: 7 },
  ];

  const handleEnrollSemester = () => {
    setIsEnrolledInSemester(true);
    setShowEnrollmentModal(true);
  };

  const handleSubjectToggle = (subjectId: string) => {
    if (selectedSubjects.includes(subjectId)) {
      setSelectedSubjects(selectedSubjects.filter(id => id !== subjectId));
    } else {
      if (selectedSubjects.length < 7) {
        setSelectedSubjects([...selectedSubjects, subjectId]);
      } else {
        alert('Você pode se matricular em no máximo 7 disciplinas');
      }
    }
  };

  const handleConfirmEnrollment = () => {
    if (selectedSubjects.length === 0) {
      alert('Selecione pelo menos uma disciplina');
      return;
    }
    alert(`Matrícula confirmada em ${selectedSubjects.length} disciplina(s)!`);
    setShowEnrollmentModal(false);
  };

  const handleUpdateProfile = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Perfil atualizado com sucesso!');
    setShowProfileModal(false);
  };

  const handleDeleteProfile = () => {
    if (profile.semestresInativos < 2) {
      alert(`Você não pode excluir seu perfil. É necessário ter 2 ou mais semestres sem matrícula. Atualmente você tem ${profile.semestresInativos} semestre(s) inativo(s).`);
      return;
    }

    if (confirm('Tem certeza que deseja excluir seu perfil? Esta ação não pode ser desfeita.')) {
      alert('Perfil excluído com sucesso!');
      onLogout();
    }
  };
  const disciplinas = [
    { nome: 'Cálculo I', professor: 'Prof. João Silva', nota: 8.5, faltas: 2, status: 'em-andamento' },
    { nome: 'Programação I', professor: 'Profa. Maria Santos', nota: 9.0, faltas: 0, status: 'em-andamento' },
    { nome: 'Física I', professor: 'Prof. Carlos Oliveira', nota: 7.5, faltas: 4, status: 'em-andamento' },
    { nome: 'Inglês Técnico', professor: 'Profa. Ana Costa', nota: 8.8, faltas: 1, status: 'em-andamento' },
  ];

  const proximasAulas = [
    { disciplina: 'Cálculo I', horario: '08:00 - 10:00', sala: 'Lab 301', data: 'Hoje' },
    { disciplina: 'Programação I', horario: '14:00 - 16:00', sala: 'Lab 205', data: 'Hoje' },
    { disciplina: 'Física I', horario: '10:00 - 12:00', sala: 'Sala 102', data: 'Amanhã' },
  ];

  const tarefasPendentes = [
    { titulo: 'Lista de Exercícios - Cálculo', prazo: '15/05/2026', disciplina: 'Cálculo I' },
    { titulo: 'Trabalho Final - Programação', prazo: '20/05/2026', disciplina: 'Programação I' },
    { titulo: 'Relatório de Laboratório', prazo: '18/05/2026', disciplina: 'Física I' },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b border-slate-200 px-6 py-4">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center">
              <User className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="text-slate-500">Discente</p>
              <p className="text-slate-900">{profile.nome}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowProfileModal(true)}
              className="flex items-center gap-2 px-4 py-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <Settings className="w-4 h-4" />
              Perfil
            </button>
            <button
              onClick={onLogout}
              className="flex items-center gap-2 px-4 py-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <LogOut className="w-4 h-4" />
              Sair
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto p-6">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="mb-2">Portal do Estudante</h1>
            <p className="text-slate-600">Bem-vindo de volta, {profile.nome}!</p>
          </div>
          <button
            onClick={handleEnrollSemester}
            disabled={isEnrolledInSemester}
            className={`px-6 py-3 rounded-lg transition-all duration-300 shadow-lg hover:shadow-xl ${
              isEnrolledInSemester
                ? 'bg-slate-300 text-slate-500 cursor-not-allowed'
                : 'bg-gradient-to-r from-blue-500 to-purple-600 text-white hover:from-blue-600 hover:to-purple-700'
            }`}
          >
            {isEnrolledInSemester ? 'Matrícula Realizada' : 'Matricular no Semestre'}
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
            <div className="flex items-center justify-between mb-2">
              <BookOpen className="w-8 h-8 text-blue-500" />
            </div>
            <p className="text-slate-500 mb-1">Disciplinas Ativas</p>
            <p className="text-blue-500">{disciplinas.length}</p>
          </div>
          <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
            <div className="flex items-center justify-between mb-2">
              <Award className="w-8 h-8 text-green-500" />
            </div>
            <p className="text-slate-500 mb-1">Média Geral</p>
            <p className="text-green-500">8.45</p>
          </div>
          <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
            <div className="flex items-center justify-between mb-2">
              <FileText className="w-8 h-8 text-orange-500" />
            </div>
            <p className="text-slate-500 mb-1">Tarefas Pendentes</p>
            <p className="text-orange-500">{tarefasPendentes.length}</p>
          </div>
          <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
            <div className="flex items-center justify-between mb-2">
              <Calendar className="w-8 h-8 text-purple-500" />
            </div>
            <p className="text-slate-500 mb-1">Próxima Aula</p>
            <p className="text-purple-500">Hoje, 08:00</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
              <h3 className="mb-6 flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-blue-500" />
                Minhas Disciplinas
              </h3>
              <div className="space-y-4">
                {disciplinas.map((disciplina, index) => (
                  <div key={index} className="border border-slate-200 rounded-lg p-4 hover:border-blue-300 transition-colors">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h4 className="mb-1">{disciplina.nome}</h4>
                        <p className="text-slate-500">{disciplina.professor}</p>
                      </div>
                      <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full">
                        Nota: {disciplina.nota}
                      </span>
                    </div>
                    <div className="flex items-center gap-4 text-slate-500 mt-3">
                      <span className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {disciplina.faltas} faltas
                      </span>
                      <span className="flex items-center gap-1">
                        <CheckCircle2 className="w-4 h-4" />
                        {disciplina.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
              <h3 className="mb-6 flex items-center gap-2">
                <Calendar className="w-5 h-5 text-purple-500" />
                Próximas Aulas
              </h3>
              <div className="space-y-3">
                {proximasAulas.map((aula, index) => (
                  <div key={index} className="border-l-4 border-purple-500 pl-4 py-2">
                    <p className="mb-1">{aula.disciplina}</p>
                    <p className="text-slate-500">{aula.horario}</p>
                    <p className="text-slate-500">{aula.sala}</p>
                    <span className="text-purple-600">{aula.data}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
              <h3 className="mb-6 flex items-center gap-2">
                <FileText className="w-5 h-5 text-orange-500" />
                Tarefas Pendentes
              </h3>
              <div className="space-y-3">
                {tarefasPendentes.map((tarefa, index) => (
                  <div key={index} className="border border-slate-200 rounded-lg p-3 hover:border-orange-300 transition-colors">
                    <p className="mb-1">{tarefa.titulo}</p>
                    <p className="text-slate-500">{tarefa.disciplina}</p>
                    <p className="text-orange-600 mt-2">Prazo: {tarefa.prazo}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>

      {showEnrollmentModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col">
            <div className="p-6 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h2 className="mb-1">Matrícula em Disciplinas</h2>
                <p className="text-slate-600">Selecione de 1 a 7 disciplinas</p>
              </div>
              <button
                onClick={() => setShowEnrollmentModal(false)}
                className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6">
              <div className="mb-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <p className="text-blue-700">
                  Disciplinas selecionadas: {selectedSubjects.length}/7
                </p>
              </div>

              <div className="space-y-3">
                {availableSubjects.map((subject) => {
                  const isSelected = selectedSubjects.includes(subject.id);
                  const isFull = subject.vagasDisponiveis === 0;

                  return (
                    <div
                      key={subject.id}
                      className={`border rounded-lg p-4 transition-all ${
                        isSelected
                          ? 'border-blue-500 bg-blue-50'
                          : isFull
                          ? 'border-slate-200 bg-slate-50 opacity-50'
                          : 'border-slate-200 hover:border-blue-300'
                      }`}
                    >
                      <div className="flex items-start gap-4">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => handleSubjectToggle(subject.id)}
                          disabled={isFull}
                          className="mt-1 w-5 h-5 text-blue-500 rounded focus:ring-2 focus:ring-blue-500"
                        />
                        <div className="flex-1">
                          <div className="flex items-start justify-between mb-2">
                            <div>
                              <h3 className="mb-1">
                                {subject.codigo} - {subject.nome}
                              </h3>
                              <p className="text-slate-500">{subject.professor}</p>
                            </div>
                            <span
                              className={`px-3 py-1 rounded-full ${
                                isFull
                                  ? 'bg-red-100 text-red-700'
                                  : subject.vagasDisponiveis < 10
                                  ? 'bg-orange-100 text-orange-700'
                                  : 'bg-green-100 text-green-700'
                              }`}
                            >
                              {isFull ? 'Lotada' : `${subject.vagasDisponiveis} vagas`}
                            </span>
                          </div>
                          <div className="flex items-center gap-4 text-slate-500">
                            <span className="flex items-center gap-1">
                              <Clock className="w-4 h-4" />
                              {subject.horario}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="p-6 border-t border-slate-200 flex gap-3">
              <button
                onClick={() => setShowEnrollmentModal(false)}
                className="flex-1 px-6 py-3 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={handleConfirmEnrollment}
                disabled={selectedSubjects.length === 0}
                className={`flex-1 px-6 py-3 rounded-lg transition-colors ${
                  selectedSubjects.length === 0
                    ? 'bg-slate-300 text-slate-500 cursor-not-allowed'
                    : 'bg-gradient-to-r from-blue-500 to-purple-600 text-white hover:from-blue-600 hover:to-purple-700'
                }`}
              >
                Confirmar Matrícula ({selectedSubjects.length} disciplina{selectedSubjects.length !== 1 ? 's' : ''})
              </button>
            </div>
          </div>
        </div>
      )}

      {showProfileModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden flex flex-col">
            <div className="p-6 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h2 className="mb-1">Meu Perfil</h2>
                <p className="text-slate-600">Gerencie suas informações pessoais</p>
              </div>
              <button
                onClick={() => setShowProfileModal(false)}
                className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <form onSubmit={handleUpdateProfile} className="flex-1 overflow-y-auto p-6 space-y-6">
              <div>
                <label className="block text-slate-700 mb-2">Nome Completo</label>
                <input
                  type="text"
                  value={profile.nome}
                  onChange={(e) => setProfile({ ...profile, nome: e.target.value })}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  disabled
                />
                <p className="text-slate-500 mt-1">Este campo não pode ser alterado</p>
              </div>

              <div>
                <label className="block text-slate-700 mb-2">E-mail Institucional</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <input
                    type="email"
                    value={profile.email}
                    className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg bg-slate-50"
                    disabled
                  />
                </div>
                <p className="text-slate-500 mt-1">Este campo não pode ser alterado</p>
              </div>

              <div>
                <label className="block text-slate-700 mb-2">E-mail Pessoal</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <input
                    type="email"
                    value={profile.emailPessoal}
                    onChange={(e) => setProfile({ ...profile, emailPessoal: e.target.value })}
                    className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 mb-2">Telefone</label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <input
                    type="tel"
                    value={profile.telefone}
                    onChange={(e) => setProfile({ ...profile, telefone: e.target.value })}
                    className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 mb-2">Endereço</label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                  <textarea
                    value={profile.endereco}
                    onChange={(e) => setProfile({ ...profile, endereco: e.target.value })}
                    rows={3}
                    className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 mb-2">Curso</label>
                <input
                  type="text"
                  value={profile.curso}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg bg-slate-50"
                  disabled
                />
              </div>

              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <Trash2 className="w-5 h-5 text-red-600 mt-0.5" />
                  <div className="flex-1">
                    <h4 className="text-red-900 mb-1">Zona de Perigo</h4>
                    <p className="text-red-700 mb-3">
                      Você pode excluir sua conta apenas se tiver 2 ou mais semestres sem matrícula em disciplinas.
                      <br />
                      <span className="font-semibold">Semestres inativos: {profile.semestresInativos}</span>
                    </p>
                    <button
                      type="button"
                      onClick={handleDeleteProfile}
                      className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors disabled:bg-red-300 disabled:cursor-not-allowed"
                      disabled={profile.semestresInativos < 2}
                    >
                      Excluir Minha Conta
                    </button>
                  </div>
                </div>
              </div>
            </form>

            <div className="p-6 border-t border-slate-200 flex gap-3">
              <button
                type="button"
                onClick={() => setShowProfileModal(false)}
                className="flex-1 px-6 py-3 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={handleUpdateProfile}
                className="flex-1 px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg hover:from-blue-600 hover:to-purple-700 transition-colors"
              >
                Salvar Alterações
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
