import { useState } from 'react';
import { Shield, Users, BookOpen, TrendingUp, Settings, LogOut, Truck, Database, Activity, CheckCircle2, XCircle, Clock, AlertCircle, Package, X, Mail, Phone, Building, FileText, Plus } from 'lucide-react';

interface AdministradorDashboardProps {
  onLogout: () => void;
}

interface PendingSupplier {
  id: string;
  nome: string;
  email: string;
  nomeEmpresa: string;
  cnpj: string;
  telefone: string;
  endereco: string;
  dataCadastro: string;
  documentosPendentes: boolean;
  diasRestantes: number;
  dataAtualizacao?: string;
}

interface Order {
  id: string;
  numero: string;
  fornecedorId: string;
  fornecedorNome: string;
  produtos: string[];
  valor: number;
  status: 'enviado' | 'confirmado' | 'recebido';
  dataPedido: string;
  dataRecebimento?: string;
}

export function AdministradorDashboard({ onLogout }: AdministradorDashboardProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'suppliers' | 'orders'>('overview');
  const [showSupplierDetailsModal, setShowSupplierDetailsModal] = useState(false);
  const [showNewOrderModal, setShowNewOrderModal] = useState(false);
  const [selectedSupplier, setSelectedSupplier] = useState<PendingSupplier | null>(null);

  const [pendingSuppliers, setPendingSuppliers] = useState<PendingSupplier[]>([
    {
      id: '1',
      nome: 'João Fornecedor',
      email: 'joao@empresa.com',
      nomeEmpresa: 'Materiais Educacionais Ltda',
      cnpj: '12.345.678/0001-90',
      telefone: '(11) 3456-7890',
      endereco: 'Av. Paulista, 1000 - São Paulo, SP',
      dataCadastro: '10/05/2026',
      documentosPendentes: true,
      diasRestantes: 2,
      dataAtualizacao: '11/05/2026'
    },
    {
      id: '2',
      nome: 'Maria Silva',
      email: 'maria@distribuidora.com',
      nomeEmpresa: 'Distribuidora ABC Ltda',
      cnpj: '98.765.432/0001-10',
      telefone: '(11) 2345-6789',
      endereco: 'Rua das Flores, 500 - São Paulo, SP',
      dataCadastro: '12/05/2026',
      documentosPendentes: false,
      diasRestantes: 3
    },
  ]);

  const [orders, setOrders] = useState<Order[]>([
    {
      id: '1',
      numero: 'PED-2026-001',
      fornecedorId: '1',
      fornecedorNome: 'Materiais Educacionais Ltda',
      produtos: ['Papel A4 - 10 resmas', 'Canetas azuis - 100 unidades'],
      valor: 850.00,
      status: 'confirmado',
      dataPedido: '10/05/2026'
    },
    {
      id: '2',
      numero: 'PED-2026-002',
      fornecedorId: '2',
      fornecedorNome: 'Distribuidora ABC Ltda',
      produtos: ['Cadernos - 30 unidades'],
      valor: 450.00,
      status: 'enviado',
      dataPedido: '12/05/2026'
    },
  ]);

  const [newOrder, setNewOrder] = useState({
    fornecedorId: '',
    produtos: '',
    valor: ''
  });

  const estatisticasGerais = [
    { label: 'Total de Alunos', valor: '2,847', icone: Users, cor: 'text-blue-500', bg: 'bg-blue-500' },
    { label: 'Total de Professores', valor: '156', icone: BookOpen, cor: 'text-green-500', bg: 'bg-green-500' },
    { label: 'Fornecedores Pendentes', valor: pendingSuppliers.length.toString(), icone: Truck, cor: 'text-orange-500', bg: 'bg-orange-500' },
    { label: 'Pedidos Ativos', valor: orders.length.toString(), icone: Package, cor: 'text-purple-500', bg: 'bg-purple-500' },
  ];

  const handleApproveSupplier = (supplierId: string) => {
    if (confirm('Tem certeza que deseja aprovar este fornecedor?')) {
      setPendingSuppliers(pendingSuppliers.filter(s => s.id !== supplierId));
      alert('Fornecedor aprovado com sucesso!');
      setShowSupplierDetailsModal(false);
    }
  };

  const handleRejectSupplier = (supplierId: string) => {
    if (confirm('Tem certeza que deseja rejeitar este fornecedor? Esta ação não pode ser desfeita.')) {
      setPendingSuppliers(pendingSuppliers.filter(s => s.id !== supplierId));
      alert('Fornecedor rejeitado.');
      setShowSupplierDetailsModal(false);
    }
  };

  const handleRequestUpdate = (supplierId: string) => {
    alert('Solicitação de atualização enviada ao fornecedor. Prazo: 3 dias.');
    setPendingSuppliers(pendingSuppliers.map(s =>
      s.id === supplierId
        ? { ...s, diasRestantes: 3, dataAtualizacao: new Date().toLocaleDateString('pt-BR') }
        : s
    ));
  };

  const handleViewSupplierDetails = (supplier: PendingSupplier) => {
    setSelectedSupplier(supplier);
    setShowSupplierDetailsModal(true);
  };

  const handleCreateOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newOrder.fornecedorId || !newOrder.produtos || !newOrder.valor) {
      alert('Preencha todos os campos');
      return;
    }

    const supplier = pendingSuppliers.find(s => s.id === newOrder.fornecedorId);
    if (!supplier) {
      alert('Fornecedor não encontrado');
      return;
    }

    const order: Order = {
      id: (orders.length + 1).toString(),
      numero: `PED-2026-${String(orders.length + 1).padStart(3, '0')}`,
      fornecedorId: newOrder.fornecedorId,
      fornecedorNome: supplier.nomeEmpresa,
      produtos: newOrder.produtos.split('\n').filter(p => p.trim()),
      valor: parseFloat(newOrder.valor),
      status: 'enviado',
      dataPedido: new Date().toLocaleDateString('pt-BR')
    };

    setOrders([...orders, order]);
    setNewOrder({ fornecedorId: '', produtos: '', valor: '' });
    setShowNewOrderModal(false);
    alert('Pedido criado e enviado ao fornecedor!');
  };

  const handleConfirmReceipt = (orderId: string) => {
    if (confirm('Confirmar que os produtos foram recebidos?')) {
      setOrders(orders.map(o =>
        o.id === orderId
          ? { ...o, status: 'recebido' as const, dataRecebimento: new Date().toLocaleDateString('pt-BR') }
          : o
      ));
      alert('Recebimento confirmado!');
    }
  };

  const dadosDepartamentos = [
    { nome: 'Engenharia', alunos: 856, professores: 42, cursos: 8 },
    { nome: 'Ciências Exatas', alunos: 624, professores: 35, cursos: 6 },
    { nome: 'Humanas', alunos: 782, professores: 48, cursos: 7 },
    { nome: 'Saúde', alunos: 585, professores: 31, cursos: 3 },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b border-slate-200 px-6 py-4">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-red-500 flex items-center justify-center">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="text-slate-500">Administrador</p>
            </div>
          </div>
          <button
            onClick={onLogout}
            className="flex items-center gap-2 px-4 py-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <LogOut className="w-4 h-4" />
            Sair
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto p-6">
        <div className="mb-8">
          <h1 className="mb-2">Painel Administrativo</h1>
          <p className="text-slate-600">Visão completa do sistema acadêmico</p>
        </div>

        <div className="flex gap-2 mb-8 border-b border-slate-200">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-6 py-3 border-b-2 transition-colors ${
              activeTab === 'overview'
                ? 'border-red-500 text-red-600'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            Visão Geral
          </button>
          <button
            onClick={() => setActiveTab('suppliers')}
            className={`px-6 py-3 border-b-2 transition-colors flex items-center gap-2 ${
              activeTab === 'suppliers'
                ? 'border-red-500 text-red-600'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Truck className="w-4 h-4" />
            Fornecedores
            {pendingSuppliers.length > 0 && (
              <span className="px-2 py-0.5 bg-orange-500 text-white rounded-full text-xs">
                {pendingSuppliers.length}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('orders')}
            className={`px-6 py-3 border-b-2 transition-colors flex items-center gap-2 ${
              activeTab === 'orders'
                ? 'border-red-500 text-red-600'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Package className="w-4 h-4" />
            Pedidos
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {estatisticasGerais.map((stat, index) => {
            const Icon = stat.icone;
            return (
              <div key={index} className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
                <div className="flex items-center justify-between mb-4">
                  <div className={`${stat.bg} w-12 h-12 rounded-lg flex items-center justify-center`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                </div>
                <p className="text-slate-500 mb-1">{stat.label}</p>
                <p className={stat.cor}>{stat.valor}</p>
              </div>
            );
          })}
        </div>

        {activeTab === 'overview' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
              <h3 className="mb-6 flex items-center gap-2">
                <Database className="w-5 h-5 text-purple-500" />
                Departamentos
              </h3>
              <div className="space-y-4">
                {dadosDepartamentos.map((dept, index) => (
                  <div key={index} className="border border-slate-200 rounded-lg p-4 hover:border-purple-300 transition-colors">
                    <h4 className="mb-3">{dept.nome}</h4>
                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <p className="text-slate-500">Alunos</p>
                        <p className="text-blue-500">{dept.alunos}</p>
                      </div>
                      <div>
                        <p className="text-slate-500">Professores</p>
                        <p className="text-green-500">{dept.professores}</p>
                      </div>
                      <div>
                        <p className="text-slate-500">Cursos</p>
                        <p className="text-purple-500">{dept.cursos}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
              <h3 className="mb-6 flex items-center gap-2">
                <Settings className="w-5 h-5 text-red-500" />
                Gerenciamento
              </h3>
              <div className="space-y-2">
                <button className="w-full text-left px-4 py-3 bg-slate-50 hover:bg-slate-100 rounded-lg transition-colors flex items-center gap-2">
                  <Users className="w-4 h-4 text-slate-500" />
                  Gerenciar Usuários
                </button>
                <button className="w-full text-left px-4 py-3 bg-slate-50 hover:bg-slate-100 rounded-lg transition-colors flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-slate-500" />
                  Cursos e Disciplinas
                </button>
                <button className="w-full text-left px-4 py-3 bg-slate-50 hover:bg-slate-100 rounded-lg transition-colors flex items-center gap-2">
                  <Database className="w-4 h-4 text-slate-500" />
                  Backup do Sistema
                </button>
                <button className="w-full text-left px-4 py-3 bg-slate-50 hover:bg-slate-100 rounded-lg transition-colors flex items-center gap-2">
                  <Settings className="w-4 h-4 text-slate-500" />
                  Configurações
                </button>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'suppliers' && (
          <div>
            <div className="mb-6 flex items-center justify-between">
              <h2>Fornecedores Pendentes</h2>
            </div>
            <div className="space-y-4">
              {pendingSuppliers.length === 0 ? (
                <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-12 text-center">
                  <Truck className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-500">Nenhum fornecedor pendente</p>
                </div>
              ) : (
                pendingSuppliers.map((supplier) => (
                  <div key={supplier.id} className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <h3 className="mb-1">{supplier.nomeEmpresa}</h3>
                        <p className="text-slate-600 mb-2">{supplier.nome}</p>
                        <div className="flex items-center gap-4 text-slate-500">
                          <span className="flex items-center gap-1">
                            <Mail className="w-4 h-4" />
                            {supplier.email}
                          </span>
                          <span className="flex items-center gap-1">
                            <Phone className="w-4 h-4" />
                            {supplier.telefone}
                          </span>
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        {supplier.documentosPendentes ? (
                          <span className="px-3 py-1 bg-red-100 text-red-700 rounded-full flex items-center gap-1">
                            <AlertCircle className="w-4 h-4" />
                            Documentos Pendentes
                          </span>
                        ) : (
                          <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full flex items-center gap-1">
                            <CheckCircle2 className="w-4 h-4" />
                            Documentos OK
                          </span>
                        )}
                        <span className="px-3 py-1 bg-orange-100 text-orange-700 rounded-full flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          {supplier.diasRestantes} dias restantes
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 mt-4 pt-4 border-t border-slate-200">
                      <button
                        onClick={() => handleViewSupplierDetails(supplier)}
                        className="px-4 py-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                      >
                        Ver Detalhes
                      </button>
                      {supplier.documentosPendentes && (
                        <button
                          onClick={() => handleRequestUpdate(supplier.id)}
                          className="px-4 py-2 text-orange-600 hover:bg-orange-50 rounded-lg transition-colors"
                        >
                          Solicitar Atualização
                        </button>
                      )}
                      <button
                        onClick={() => handleApproveSupplier(supplier.id)}
                        disabled={supplier.documentosPendentes}
                        className={`px-4 py-2 rounded-lg transition-colors ${
                          supplier.documentosPendentes
                            ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                            : 'bg-green-500 text-white hover:bg-green-600'
                        }`}
                      >
                        Aprovar
                      </button>
                      <button
                        onClick={() => handleRejectSupplier(supplier.id)}
                        className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors"
                      >
                        Rejeitar
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {activeTab === 'orders' && (
          <div>
            <div className="mb-6 flex items-center justify-between">
              <h2>Gerenciar Pedidos</h2>
              <button
                onClick={() => setShowNewOrderModal(true)}
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg hover:from-blue-600 hover:to-purple-700 transition-colors"
              >
                <Plus className="w-4 h-4" />
                Novo Pedido
              </button>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {orders.map((order) => (
                <div key={order.id} className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="mb-1">{order.numero}</h3>
                      <p className="text-slate-600">{order.fornecedorNome}</p>
                    </div>
                    <span className={`px-3 py-1 rounded-full ${
                      order.status === 'enviado' ? 'bg-blue-100 text-blue-700' :
                      order.status === 'confirmado' ? 'bg-orange-100 text-orange-700' :
                      'bg-green-100 text-green-700'
                    }`}>
                      {order.status === 'enviado' ? 'Enviado' :
                       order.status === 'confirmado' ? 'Confirmado' :
                       'Recebido'}
                    </span>
                  </div>
                  <div className="mb-4">
                    <p className="text-slate-600 mb-2">Produtos:</p>
                    <ul className="list-disc list-inside text-slate-500 space-y-1">
                      {order.produtos.map((produto, idx) => (
                        <li key={idx}>{produto}</li>
                      ))}
                    </ul>
                  </div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-slate-600">Valor:</span>
                    <span className="text-green-600">R$ {order.valor.toFixed(2)}</span>
                  </div>
                  <div className="flex items-center justify-between mb-4 pb-4 border-b border-slate-200">
                    <span className="text-slate-600">Data do Pedido:</span>
                    <span className="text-slate-600">{order.dataPedido}</span>
                  </div>
                  {order.status === 'confirmado' && (
                    <button
                      onClick={() => handleConfirmReceipt(order.id)}
                      className="w-full px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
                    >
                      Confirmar Recebimento
                    </button>
                  )}
                  {order.status === 'recebido' && (
                    <div className="text-center text-green-600 py-2">
                      Recebido em {order.dataRecebimento}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      {showSupplierDetailsModal && selectedSupplier && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden flex flex-col">
            <div className="p-6 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h2 className="mb-1">Detalhes do Fornecedor</h2>
                <p className="text-slate-600">{selectedSupplier.nomeEmpresa}</p>
              </div>
              <button
                onClick={() => setShowSupplierDetailsModal(false)}
                className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              <div>
                <label className="block text-slate-700 mb-2">Nome do Responsável</label>
                <p className="px-4 py-3 bg-slate-50 rounded-lg">{selectedSupplier.nome}</p>
              </div>

              <div>
                <label className="block text-slate-700 mb-2">E-mail</label>
                <p className="px-4 py-3 bg-slate-50 rounded-lg">{selectedSupplier.email}</p>
              </div>

              <div>
                <label className="block text-slate-700 mb-2">Telefone</label>
                <p className="px-4 py-3 bg-slate-50 rounded-lg">{selectedSupplier.telefone}</p>
              </div>

              <div>
                <label className="block text-slate-700 mb-2">Endereço</label>
                <p className="px-4 py-3 bg-slate-50 rounded-lg">{selectedSupplier.endereco}</p>
              </div>

              <div className="border-t border-slate-200 pt-6">
                <h3 className="mb-4 text-slate-700">Dados da Empresa</h3>
              </div>

              <div>
                <label className="block text-slate-700 mb-2">Nome da Empresa</label>
                <p className="px-4 py-3 bg-slate-50 rounded-lg">{selectedSupplier.nomeEmpresa}</p>
              </div>

              <div>
                <label className="block text-slate-700 mb-2">CNPJ</label>
                <p className="px-4 py-3 bg-slate-50 rounded-lg">{selectedSupplier.cnpj}</p>
              </div>

              <div>
                <label className="block text-slate-700 mb-2">Data de Cadastro</label>
                <p className="px-4 py-3 bg-slate-50 rounded-lg">{selectedSupplier.dataCadastro}</p>
              </div>

              {selectedSupplier.dataAtualizacao && (
                <div>
                  <label className="block text-slate-700 mb-2">Última Atualização</label>
                  <p className="px-4 py-3 bg-slate-50 rounded-lg">{selectedSupplier.dataAtualizacao}</p>
                </div>
              )}

              <div className={`${selectedSupplier.documentosPendentes ? 'bg-red-50 border-red-200' : 'bg-green-50 border-green-200'} border rounded-lg p-4`}>
                <div className="flex items-center gap-2">
                  {selectedSupplier.documentosPendentes ? (
                    <>
                      <AlertCircle className="w-5 h-5 text-red-600" />
                      <span className="text-red-700">Documentos pendentes - Solicite atualização</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-5 h-5 text-green-600" />
                      <span className="text-green-700">Todos os documentos estão em ordem</span>
                    </>
                  )}
                </div>
              </div>

              <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Clock className="w-5 h-5 text-orange-600" />
                  <span className="text-orange-700">Prazo para atualização</span>
                </div>
                <p className="text-orange-600">
                  {selectedSupplier.diasRestantes} dia(s) restante(s). Após este prazo, o cadastro será automaticamente rejeitado.
                </p>
              </div>
            </div>

            <div className="p-6 border-t border-slate-200 flex gap-3">
              <button
                onClick={() => handleRejectSupplier(selectedSupplier.id)}
                className="flex-1 px-6 py-3 border border-red-300 text-red-700 rounded-lg hover:bg-red-50 transition-colors"
              >
                Rejeitar
              </button>
              {selectedSupplier.documentosPendentes && (
                <button
                  onClick={() => handleRequestUpdate(selectedSupplier.id)}
                  className="flex-1 px-6 py-3 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors"
                >
                  Solicitar Atualização
                </button>
              )}
              <button
                onClick={() => handleApproveSupplier(selectedSupplier.id)}
                disabled={selectedSupplier.documentosPendentes}
                className={`flex-1 px-6 py-3 rounded-lg transition-colors ${
                  selectedSupplier.documentosPendentes
                    ? 'bg-slate-300 text-slate-500 cursor-not-allowed'
                    : 'bg-green-500 text-white hover:bg-green-600'
                }`}
              >
                Aprovar Fornecedor
              </button>
            </div>
          </div>
        </div>
      )}

      {showNewOrderModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-2xl w-full">
            <div className="p-6 border-b border-slate-200 flex items-center justify-between">
              <h2>Criar Novo Pedido</h2>
              <button
                onClick={() => setShowNewOrderModal(false)}
                className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <form onSubmit={handleCreateOrder} className="p-6 space-y-6">
              <div>
                <label className="block text-slate-700 mb-2">Fornecedor *</label>
                <select
                  value={newOrder.fornecedorId}
                  onChange={(e) => setNewOrder({ ...newOrder, fornecedorId: e.target.value })}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                >
                  <option value="">Selecione um fornecedor</option>
                  {pendingSuppliers.map((supplier) => (
                    <option key={supplier.id} value={supplier.id}>
                      {supplier.nomeEmpresa}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-700 mb-2">Produtos (um por linha) *</label>
                <textarea
                  value={newOrder.produtos}
                  onChange={(e) => setNewOrder({ ...newOrder, produtos: e.target.value })}
                  rows={5}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Papel A4 - 10 resmas&#10;Canetas azuis - 100 unidades"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-700 mb-2">Valor Total (R$) *</label>
                <input
                  type="number"
                  step="0.01"
                  value={newOrder.valor}
                  onChange={(e) => setNewOrder({ ...newOrder, valor: e.target.value })}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="0.00"
                  required
                />
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowNewOrderModal(false)}
                  className="flex-1 px-6 py-3 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg hover:from-blue-600 hover:to-purple-700 transition-colors"
                >
                  Criar Pedido
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
