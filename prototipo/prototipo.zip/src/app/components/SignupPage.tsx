import { useState } from 'react';
import { GraduationCap, BookOpen, FileText, Shield, Truck, ArrowLeft, Mail, Lock, User, Phone, MapPin, Building } from 'lucide-react';
import { UserRole } from '../App';

interface SignupPageProps {
  onSignup: (data: SignupData) => void;
  onBackToLogin: () => void;
}

export interface SignupData {
  role: UserRole;
  nome: string;
  email: string;
  password: string;
  telefone: string;
  endereco: string;
  // Campos específicos para fornecedor
  nomeEmpresa?: string;
  cnpj?: string;
  documentos?: File[];
}

export function SignupPage({ onSignup, onBackToLogin }: SignupPageProps) {
  const [step, setStep] = useState<'role' | 'form'>('role');
  const [selectedRole, setSelectedRole] = useState<UserRole>(null);
  const [formData, setFormData] = useState<SignupData>({
    role: null,
    nome: '',
    email: '',
    password: '',
    telefone: '',
    endereco: '',
    nomeEmpresa: '',
    cnpj: '',
  });

  const roles = [
    {
      id: 'discente' as const,
      title: 'Discente',
      description: 'Cadastro para estudantes',
      icon: GraduationCap,
      color: 'bg-blue-500',
    },
    {
      id: 'docente' as const,
      title: 'Docente',
      description: 'Cadastro para professores',
      icon: BookOpen,
      color: 'bg-green-500',
    },
    {
      id: 'funcionario' as const,
      title: 'Funcionário Acadêmico',
      description: 'Cadastro para funcionários',
      icon: FileText,
      color: 'bg-orange-500',
    },
    {
      id: 'fornecedor' as const,
      title: 'Fornecedor',
      description: 'Cadastro para fornecedores',
      icon: Truck,
      color: 'bg-purple-500',
    },
  ];

  const handleRoleSelect = (role: UserRole) => {
    setSelectedRole(role);
    setFormData({ ...formData, role });
    setStep('form');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.nome || !formData.email || !formData.password) {
      alert('Por favor, preencha todos os campos obrigatórios');
      return;
    }

    if (selectedRole === 'fornecedor' && (!formData.nomeEmpresa || !formData.cnpj)) {
      alert('Por favor, preencha os dados da empresa');
      return;
    }

    onSignup(formData);
  };

  if (step === 'role') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100 p-4">
        <button
          onClick={onBackToLogin}
          className="absolute top-6 left-6 flex items-center gap-2 px-4 py-2 text-slate-600 hover:text-slate-900 hover:bg-white rounded-lg transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Voltar ao Login
        </button>

        <div className="text-center mb-12">
          <h1 className="mb-4">Criar Nova Conta</h1>
          <p className="text-slate-600">Selecione o tipo de cadastro</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl w-full">
          {roles.map((role) => {
            const Icon = role.icon;
            return (
              <button
                key={role.id}
                onClick={() => handleRoleSelect(role.id)}
                className="group relative bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 border border-slate-200"
              >
                <div className={`${role.color} w-16 h-16 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                  <Icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="mb-2">{role.title}</h3>
                <p className="text-slate-500">{role.description}</p>
              </button>
            );
          })}
        </div>
      </div>
    );
  }

  const roleInfo = roles.find(r => r.id === selectedRole);
  const Icon = roleInfo?.icon || User;

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100 p-4">
      <div className="w-full max-w-2xl">
        <button
          onClick={() => setStep('role')}
          className="flex items-center gap-2 px-4 py-2 text-slate-600 hover:text-slate-900 hover:bg-white rounded-lg transition-colors mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          Voltar
        </button>

        <div className="bg-white rounded-2xl shadow-xl p-8 border border-slate-200">
          <div className="flex items-center gap-4 mb-8">
            <div className={`${roleInfo?.color} w-16 h-16 rounded-xl flex items-center justify-center`}>
              <Icon className="w-8 h-8 text-white" />
            </div>
            <div>
              <h2 className="mb-1">Cadastro - {roleInfo?.title}</h2>
              <p className="text-slate-600">Preencha seus dados</p>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-slate-700 mb-2">Nome Completo *</label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <input
                  type="text"
                  value={formData.nome}
                  onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                  className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Seu nome completo"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-700 mb-2">E-mail *</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="seu.email@example.com"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-700 mb-2">Senha *</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <input
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Mínimo 6 caracteres"
                  required
                  minLength={6}
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-700 mb-2">Telefone</label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <input
                  type="tel"
                  value={formData.telefone}
                  onChange={(e) => setFormData({ ...formData, telefone: e.target.value })}
                  className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="(11) 98765-4321"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-700 mb-2">Endereço</label>
              <div className="relative">
                <MapPin className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                <textarea
                  value={formData.endereco}
                  onChange={(e) => setFormData({ ...formData, endereco: e.target.value })}
                  rows={2}
                  className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Seu endereço completo"
                />
              </div>
            </div>

            {selectedRole === 'fornecedor' && (
              <>
                <div className="border-t border-slate-200 pt-6">
                  <h3 className="mb-4 text-slate-700">Dados da Empresa</h3>
                </div>

                <div>
                  <label className="block text-slate-700 mb-2">Nome da Empresa *</label>
                  <div className="relative">
                    <Building className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    <input
                      type="text"
                      value={formData.nomeEmpresa}
                      onChange={(e) => setFormData({ ...formData, nomeEmpresa: e.target.value })}
                      className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Razão social"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-slate-700 mb-2">CNPJ *</label>
                  <div className="relative">
                    <FileText className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    <input
                      type="text"
                      value={formData.cnpj}
                      onChange={(e) => setFormData({ ...formData, cnpj: e.target.value })}
                      className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="00.000.000/0000-00"
                      required
                    />
                  </div>
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <p className="text-blue-700">
                    Seu cadastro será enviado para análise do administrador. Você receberá uma notificação quando for aprovado.
                  </p>
                </div>
              </>
            )}

            <div className="flex gap-3 pt-4">
              <button
                type="button"
                onClick={onBackToLogin}
                className="flex-1 px-6 py-3 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="flex-1 px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg hover:from-blue-600 hover:to-purple-700 transition-all duration-300 shadow-lg hover:shadow-xl"
              >
                Criar Conta
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
