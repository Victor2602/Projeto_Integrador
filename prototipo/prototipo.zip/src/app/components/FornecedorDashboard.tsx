import { useState } from 'react';
import { Truck, Package, CheckCircle2, Clock, LogOut, User, Settings, Phone, Mail, MapPin, X, AlertCircle, Building } from 'lucide-react';
import { UserData } from '../App';

interface FornecedorDashboardProps {
  onLogout: () => void;
  userData: UserData;
}

interface Order {
  id: string;
  numero: string;
  data: string;
  produtos: string[];
  valor: number;
  status: 'pendente' | 'confirmado' | 'entregue';
  prazoEntrega: string;
}

interface FornecedorProfile {
  nome: string;
  email: string;
  emailPessoal: string;
  telefone: string;
  endereco: string;
  nomeEmpresa: string;
  cnpj: string;
  status: 'pending' | 'approved' | 'rejected';
}

export function FornecedorDashboard({ onLogout, userData }: FornecedorDashboardProps) {
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [orders, setOrders] = useState<Order[]>([
    {
      id: '1',
      numero: 'PED-2026-001',
      data: '10/05/2026',
      produtos: ['Papel A4 - 10 resmas', 'Canetas azuis - 100 unidades', 'Marcadores - 50 unidades'],
      valor: 850.00,
      status: 'pendente',
      prazoEntrega: '20/05/2026'
    },
    {
      id: '2',
      numero: 'PED-2026-002',
      data: '12/05/2026',
      produtos: ['Cadernos universitários - 30 unidades', 'Lápis - 200 unidades'],
      valor: 450.00,
      status: 'pendente',
      prazoEntrega: '22/05/2026'
    },
    {
      id: '3',
      numero: 'PED-2026-003',
      data: '08/05/2026',
      produtos: ['Impressoras multifuncionais - 2 unidades'],
      valor: 2800.00,
      status: 'confirmado',
      prazoEntrega: '18/05/2026'
    },
  ]);

  const [profile, setProfile] = useState<FornecedorProfile>({
    nome: userData.name,
    email: userData.email,
    emailPessoal: 'fornecedor@empresa.com',
    telefone: '(11) 3456-7890',
    endereco: 'Av. Paulista, 1000 - São Paulo, SP',
    nomeEmpresa: 'Materiais Educacionais Ltda',
    cnpj: '12.345.678/0001-90',
    status: 'approved'
  });

  const handleConfirmOrder = (orderId: string) => {
    setOrders(orders.map(order =>
      order.id === orderId
        ? { ...order, status: 'confirmado' as const }
        : order
    ));
    alert('Pedido confirmado com sucesso!');
  };

  const handleUpdateProfile = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Perfil atualizado com sucesso!');
    setShowProfileModal(false);
  };

  const pendingOrders = orders.filter(o => o.status === 'pendente');
  const confirmedOrders = orders.filter(o => o.status === 'confirmado');

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b border-slate-200 px-6 py-4">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-purple-500 flex items-center justify-center">
              <Truck className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="text-slate-500">Fornecedor</p>
              <p className="text-slate-900">{profile.nome}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {profile.status === 'pending' && (
              <div className="flex items-center gap-2 px-4 py-2 bg-orange-100 text-orange-700 rounded-lg">
                <Clock className="w-4 h-4" />
                Aguardando Aprovação
              </div>
            )}
            {profile.status === 'approved' && (
              <div className="flex items-center gap-2 px-4 py-2 bg-green-100 text-green-700 rounded-lg">
                <CheckCircle2 className="w-4 h-4" />
                Aprovado
              </div>
            )}
            <button
              onClick={() => setShowProfileModal(true)}
              className="flex items-center gap-2 px-4 py-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <Settings className="w-4 h-4" />
              Perfil
            </button>
            <button
              onClick={onLogout}
              className="flex items-center gap-2 px-4 py-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <LogOut className="w-4 h-4" />
              Sair
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto p-6">
        <div className="mb-8">
          <h1 className="mb-2">Portal do Fornecedor</h1>
          <p className="text-slate-600">Bem-vindo, {profile.nomeEmpresa}!</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
            <div className="flex items-center justify-between mb-2">
              <Clock className="w-8 h-8 text-orange-500" />
            </div>
            <p className="text-slate-500 mb-1">Pedidos Pendentes</p>
            <p className="text-orange-500">{pendingOrders.length}</p>
          </div>
          <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
            <div className="flex items-center justify-between mb-2">
              <CheckCircle2 className="w-8 h-8 text-green-500" />
            </div>
            <p className="text-slate-500 mb-1">Pedidos Confirmados</p>
            <p className="text-green-500">{confirmedOrders.length}</p>
          </div>
          <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
            <div className="flex items-center justify-between mb-2">
              <Package className="w-8 h-8 text-blue-500" />
            </div>
            <p className="text-slate-500 mb-1">Total de Pedidos</p>
            <p className="text-blue-500">{orders.length}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
            <h3 className="mb-6 flex items-center gap-2">
              <Clock className="w-5 h-5 text-orange-500" />
              Pedidos Pendentes
            </h3>
            <div className="space-y-4">
              {pendingOrders.length === 0 ? (
                <p className="text-slate-500 text-center py-8">Nenhum pedido pendente</p>
              ) : (
                pendingOrders.map((order) => (
                  <div key={order.id} className="border border-slate-200 rounded-lg p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h4 className="mb-1">{order.numero}</h4>
                        <p className="text-slate-500">Data: {order.data}</p>
                      </div>
                      <span className="px-3 py-1 bg-orange-100 text-orange-700 rounded-full">
                        Pendente
                      </span>
                    </div>
                    <div className="mb-3">
                      <p className="text-slate-600 mb-2">Produtos:</p>
                      <ul className="list-disc list-inside text-slate-500 space-y-1">
                        {order.produtos.map((produto, idx) => (
                          <li key={idx}>{produto}</li>
                        ))}
                      </ul>
                    </div>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-slate-600">Valor:</span>
                      <span className="text-green-600">R$ {order.valor.toFixed(2)}</span>
                    </div>
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-slate-600">Prazo de Entrega:</span>
                      <span className="text-blue-600">{order.prazoEntrega}</span>
                    </div>
                    <button
                      onClick={() => handleConfirmOrder(order.id)}
                      className="w-full px-4 py-2 bg-gradient-to-r from-green-500 to-green-600 text-white rounded-lg hover:from-green-600 hover:to-green-700 transition-colors"
                    >
                      Confirmar Pedido
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
            <h3 className="mb-6 flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-green-500" />
              Pedidos Confirmados
            </h3>
            <div className="space-y-4">
              {confirmedOrders.length === 0 ? (
                <p className="text-slate-500 text-center py-8">Nenhum pedido confirmado</p>
              ) : (
                confirmedOrders.map((order) => (
                  <div key={order.id} className="border border-green-200 bg-green-50 rounded-lg p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h4 className="mb-1">{order.numero}</h4>
                        <p className="text-slate-500">Data: {order.data}</p>
                      </div>
                      <span className="px-3 py-1 bg-green-500 text-white rounded-full flex items-center gap-1">
                        <CheckCircle2 className="w-4 h-4" />
                        Confirmado
                      </span>
                    </div>
                    <div className="mb-3">
                      <p className="text-slate-600 mb-2">Produtos:</p>
                      <ul className="list-disc list-inside text-slate-500 space-y-1">
                        {order.produtos.map((produto, idx) => (
                          <li key={idx}>{produto}</li>
                        ))}
                      </ul>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-600">Valor:</span>
                      <span className="text-green-600">R$ {order.valor.toFixed(2)}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </main>

      {showProfileModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden flex flex-col">
            <div className="p-6 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h2 className="mb-1">Meu Perfil</h2>
                <p className="text-slate-600">Gerencie suas informações</p>
              </div>
              <button
                onClick={() => setShowProfileModal(false)}
                className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <form onSubmit={handleUpdateProfile} className="flex-1 overflow-y-auto p-6 space-y-6">
              <div>
                <label className="block text-slate-700 mb-2">Nome Completo</label>
                <input
                  type="text"
                  value={profile.nome}
                  onChange={(e) => setProfile({ ...profile, nome: e.target.value })}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>

              <div>
                <label className="block text-slate-700 mb-2">E-mail Institucional</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <input
                    type="email"
                    value={profile.email}
                    className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg bg-slate-50"
                    disabled
                  />
                </div>
                <p className="text-slate-500 mt-1">Este campo não pode ser alterado</p>
              </div>

              <div>
                <label className="block text-slate-700 mb-2">E-mail Pessoal</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <input
                    type="email"
                    value={profile.emailPessoal}
                    onChange={(e) => setProfile({ ...profile, emailPessoal: e.target.value })}
                    className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 mb-2">Telefone</label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <input
                    type="tel"
                    value={profile.telefone}
                    onChange={(e) => setProfile({ ...profile, telefone: e.target.value })}
                    className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 mb-2">Endereço</label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                  <textarea
                    value={profile.endereco}
                    onChange={(e) => setProfile({ ...profile, endereco: e.target.value })}
                    rows={3}
                    className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
              </div>

              <div className="border-t border-slate-200 pt-6">
                <h3 className="mb-4 text-slate-700">Dados da Empresa</h3>
              </div>

              <div>
                <label className="block text-slate-700 mb-2">Nome da Empresa</label>
                <div className="relative">
                  <Building className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <input
                    type="text"
                    value={profile.nomeEmpresa}
                    onChange={(e) => setProfile({ ...profile, nomeEmpresa: e.target.value })}
                    className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 mb-2">CNPJ</label>
                <input
                  type="text"
                  value={profile.cnpj}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg bg-slate-50"
                  disabled
                />
                <p className="text-slate-500 mt-1">Este campo não pode ser alterado</p>
              </div>
            </form>

            <div className="p-6 border-t border-slate-200 flex gap-3">
              <button
                type="button"
                onClick={() => setShowProfileModal(false)}
                className="flex-1 px-6 py-3 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={handleUpdateProfile}
                className="flex-1 px-6 py-3 bg-gradient-to-r from-purple-500 to-purple-600 text-white rounded-lg hover:from-purple-600 hover:to-purple-700 transition-colors"
              >
                Salvar Alterações
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
