
  # Prototype for User Cases

  This is a code bundle for Prototype for User Cases. The original project is available at https://www.figma.com/design/nOIYdhn0TS0l9NKhmb37gV/Prototype-for-User-Cases.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  